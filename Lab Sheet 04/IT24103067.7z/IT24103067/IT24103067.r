setwd("C:\\Users\\IT24103067\\Desktop\\IT24103067")

#Import the dataset
branch_data <- read.csv("Exercise.txt", header = TRUE)
print(branch_data)

#02	Identify the variable type 
print("Variable Types and Scales:\n")
print("Branch -> Categorical (Nominal)\n")
print("Sales_X1 -> Numeric (Ratio)\n")
print("Advertising_X2 -> Numeric (Ratio)\n")
print("Years_X3 -> Numeric (Ratio)\n")

#03  boxplot for sales and interpret the shape
boxplot(branch_data$Sales_X1, 
        main = "Boxplot of Sales", 
        ylab = "Sales", 
        col = "pink")

# 04 Calculate the five number summary and IQR
print("Five-Number Summary for Advertising:\n")
print(summary(branch_data$Advertising_X2))

print("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))

#05  find the outliers in a numeric vector and check for outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

years_outliers <- find_outliers(branch_data$Years_X3)
print("Outliers in Years variable:\n")
print(years_outliers)



